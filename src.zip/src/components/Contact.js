import React from "react";
import "./../scss/_contact.scss";
import { rubberBand } from "react-animations";
import Radium, { StyleRoot } from "radium";

const Contact = () => {
  const styles = {
    rubberband: {
      animation: "x 1s 5s",
      animationName: Radium.keyframes(rubberBand, "rubberband"),
    },
  };
  return (
    <section className="contact-bg d-flex">
      <div color="white" className="container">
        <img></img>
        <div className="col-md-12 d-flex">
          <div className="col-md-6">
            <h2>QUICK CONNECT</h2>
          </div>
          <div className="col-md-6">
            <StyleRoot>
              <button className="btn btn-black" style={styles.rubberband}>
                LET'S GET STARTED
              </button>
            </StyleRoot>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
