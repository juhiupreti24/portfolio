import React from "react";
import { FaTimes } from "react-icons/fa";
import "./../scss/_modal.scss";

const ContactForm = ({ showModal, setShowModal }) => {
  return (
    <>
      {showModal ? (
        <section className="modal-main">
          <nav className="contactnav p3 pl5 d-flex">
            <h3 color="white">Contact form</h3>
            <FaTimes
              className=""
              color="black"
              cursor="pointer"
              onClick={() => setShowModal(prev => !prev)}
            />
          </nav>
          <form className="mt10" className="formContainer">
            <div className="m5">
              <label id="fullname" name="fullname">
                Name
              </label>
              <input className="ml3"></input>
            </div>
            <div className="m5">
              <label id="email" name="email">
                Email
              </label>
              <input className="ml3"></input>
            </div>
            <div className="m5">
              <label id="query" name="query">
                Query details
              </label>
              <textarea></textarea>
            </div>
          </form>
          <div className="submitContainer">
            <button
              className="btn btn-grey btn-border"
              type="button"
              onClick={() => setShowModal(prev => !prev)}
            >
              Close
            </button>
            <button className="btn btn-black" type="button">
              Submit
            </button>
          </div>
        </section>
      ) : null}
    </>
  );
};

export default ContactForm;
