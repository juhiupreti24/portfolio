import React from "react";
import "./../scss/_header.scss";
import { FaDownload, FaFacebook, FaInstagram, FaTwitter, FaLinkedin} from "react-icons/fa";
import { bounce, slideInUp } from "react-animations";
import Radium, { StyleRoot } from "radium";
import { saveAs } from "file-saver";

const Header = () => {
  const logo = "./../assets/images/hero-bg.jpg";
  const styles = {
    bounce: {
      animation: "x 1s",
      animationName: Radium.keyframes(bounce, "bounce"),
    }
  };

  const downloadResume = () => {
    saveAs(
      "./../assets/docs/JuhiUpretiResume.docx",
      "example.docx"
    );
  };
  return (
    <div className="img-text-wrapper col-md-12 d-flex">
      <div className="logo-wrapper col-md-7">
        <h2 className="greeting-txt">
          Hello! I m <br />
          Juhi Upreti
        </h2>
        <h4 className="greeting-txt">
          Frontend developer specializing in Angular, Data Science
        </h4>
        <div className="d-flex site-btn">
          <StyleRoot>
            <div className="d-flex" style={{margin: "auto"}}>
              <h5 className="mt20">Get resume</h5>
              <FaDownload cursor="pointer" className="mt20 ml4" download="Resume"/>
            </div>
          </StyleRoot>
        </div>
      </div>
      <div className="info-wrapper col-md-5 d-flex">
        <div className="circle-container">
        <a href='#' className='deg45'>
          <FaFacebook color="white" cursor="pointer" className="ml4" />
        </a>
        <a href='#' className='deg135'>
        <FaTwitter color="white" cursor="pointer" className="ml4" />
        </a>
        <a href='#' className='deg180'>
        <FaInstagram color="white" cursor="pointer" className="ml4" />
        </a>
        <a href='#' className='deg20'>
        <FaLinkedin color="white" cursor="pointer" className="ml4" />
        </a>
        </div>
        <div className="pr2" style={{borderRight: '2px solid white'}}>
        <img src={require("./../assets/images/contact-icon.png")} />
        </div>
       
      </div>
    </div>
  );
};

export default Header;
