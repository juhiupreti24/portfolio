import React from 'react';
import './../scss/_showcase.scss';

const WorkShowcase = () => {
  return <section className='showcase-bg'>
      <div className='container'>
          <div className='d-flex'>
          <h4>My WORK</h4>
          <span
              className="ml10 mt3"
              style={{
                height: "5px",
                width: "100px",
                backgroundColor: "white",
              }}></span>
        </div>
          <h3 className='mt4'>WORK SHOWCASE</h3>
      </div>
  </section>;
};

export default WorkShowcase;
