import React from "react";
import "./../scss/_offers.scss";

const Offerings = () => {
  return (
    <section className="offer-bg">
      <div className="container">
        <h5 className="">Our services</h5>
        <h4 className="mb15">WHAT WE ARE OFFERING</h4>
        <div className="col-md-12 col-12 d-flex">
          <div className="col-md-3 col-3">
            <img src={require("./../assets/images/we-offer-icon1.png")}></img>
            <h4 className="mt5 ml5">UI/UX <br/>CREATIVE DESIGN</h4>
          </div>
          <div className="ml4 col-md-3 col-3">
            <img src={require("./../assets/images/we-offer-icon2.png")}></img>
            <h4 className="mt5 ml5" style={{width: 150}}>QUALITY Coding Development</h4>
          </div>
          <div className="ml4 col-md-3 col-3">
            <img src={require("./../assets/images/we-offer-icon3.png")}></img>
            <h4 className="mt5 ml5" style={{width: 150}}>Unique Technology</h4>
          </div>
          <div className="ml4 col-md-3 col-3">
            <img src={require("./../assets/images/we-offer-icon4.png")}></img>
            <h4 className="mt5 ml5" style={{width: 120}}>Excellent Support</h4>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Offerings;
