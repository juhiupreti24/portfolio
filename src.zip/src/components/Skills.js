import React from "react";
import "./../scss/_skills.scss";
import PercentBar from "./PercentBar";
import { FaDownload } from "react-icons/fa";

const Skills = () => {
  const bgColor = "#7600d8";
  return (
    <div className="skills-bg">
      <div className="col-md-12 col-12 d-flex container">
        <div className="col-md-6 col-6">
          <div className="d-flex">
            <h3>Skills</h3>
            <span
              className="ml10 mt3"
              style={{
                height: "5px",
                width: "100px",
                backgroundColor: "#7600d8",
              }}
            ></span>
          </div>
          <h2>My Special skills</h2>
          <p style={{ width: "70%" }}>
            Dummy text to be replaced here slakjdkasdlj skajd jasdhkj hasdj skdj
            slkdja aksjd kasjd
          </p>
          <div className="d-flex site-btn mt10">
            <div className="d-flex">
              <h5>Get resume</h5>
              <FaDownload cursor="pointer" className="mt1 ml4" />
            </div>
          </div>
        </div>
        <div className="col-md-6 col-6">
          <PercentBar bgcolor={bgColor} completed={70} label={"Leadership"} />
          <PercentBar bgcolor={bgColor} completed={90} label={"Communication"} />
          <PercentBar bgcolor={bgColor} completed={80} label={"Teamwork"} />
          <PercentBar bgcolor={bgColor} completed={100} label={"Development"} />
        </div>
      </div>
    </div>
  );
};

export default Skills;
