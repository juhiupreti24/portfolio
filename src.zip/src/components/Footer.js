import React from "react";
import { FaFacebook, FaInstagram, FaLinkedin, FaTwitter } from "react-icons/fa";

const Footer = () => {
  return (
    <section className="footer-bg col-md-12 d-flex">
      <div className="col-md-8 justify-center">
        LET'S WORK TOGETHER. JUST DROP ME A LINE - <span className="glow">JUHIUPRETI24@GMAIL.COM</span>
      </div>
      <div className="col-md-4 justify-right">
        <FaFacebook color="#7600d8" cursor="pointer" className="ml4" />
        <FaTwitter color="#7600d8" cursor="pointer" className="ml4" />
        <FaInstagram color="#7600d8" cursor="pointer" className="ml4" />
        <FaLinkedin color="#7600d8" cursor="pointer" className="ml4" />
      </div>
    </section>
  );
};

export default Footer;
