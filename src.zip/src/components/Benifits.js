import React from "react";
import "./../scss/_benifits.scss";
const Benifits = () => {
  return (
    <section className="benifit-container p-0">
      <div className="col-md-12 d-flex">
        <div className="col-md-5 benifits offset-sm-1">
            <div className="d-flex">
              <h2>Our benifits</h2>
              <div
                className="mt4 ml5"
                style={{
                  height: "5px",
                  width: "100px",
                  backgroundColor: "#7600d8",
                }}
              ></div>
            </div>
            <div className="mt5 mb5">
              <h2>WHY WE'RE BEST</h2>
            </div>
          <div className="col-md-6 col-sm-6 col-6 d-flex">
            <div className="col-12 pl0 pr3">
              <img src={require("./../assets/images/we-best-icon1.png")} />
              <h4 className="mt4" style={{ cursor: "pointer" }}>
                Years of <br />
                Experience
              </h4>
            </div>
            <div className="col-12 pl0">
              <img src={require("./../assets/images/we-best-icon2.png")} />
              <h4 className="mt4" style={{ cursor: "pointer" }}>
                The best <br />
                User interfaces
              </h4>
            </div>
          </div>
          <div className="col-md-6 col-sm-6 col-6 d-flex">
            <div className="col-12 pl0 pr3">
              <img src={require("./../assets/images/we-best-icon3.png")} />
              <h4 className="mt4" style={{ cursor: "pointer" }}>
                Completed
                <br /> projects
              </h4>
            </div>
            <div className="col-12 pl0">
              <img src={require("./../assets/images/we-best-icon4.png")} />
              <h4 className="mt4" style={{ cursor: "pointer" }}>
                Quick smooth <br /> web Development
              </h4>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <img src={require("./../assets/images/image1.jpg")}></img>
        </div>
      </div>
    </section>
  );
};

export default Benifits;
