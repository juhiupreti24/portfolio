import React from 'react';
import Benifits from './Benifits';
import Contact from './Contact';
import Offerings from './Offerings';
import Skills from './Skills';
import WorkShowcase from './WorkShowcase';

const Content = () => {
  return <div>
      <Offerings />
      <Skills />
      <WorkShowcase />
      <Benifits />
      <Contact />
  </div>;
};

export default Content;
