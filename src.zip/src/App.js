import "./App.scss";
import "./scss/main.scss";
import Header from "./components/Header";
import Content from "./components/Content";
import Footer from "./components/Footer";
import "bootstrap/dist/css/bootstrap.min.css";
import { bounce, slideInUp } from "react-animations";
import Radium, { StyleRoot } from "radium";
import { BsFillChatRightTextFill } from "react-icons/bs";
import ContactForm from "./components/ContactForm";
import { useState } from "react";

function App() {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => {
    setShowModal((prev) => !prev);
  };
  const styles = {
    slideInUp: {
      animation: "x 1s",
      animationName: Radium.keyframes(slideInUp, "slideInUp"),
    },
  };
  return (
    <StyleRoot>
      {/* <div>{show}</div> */}
      <div className="App">
        <Header />
        <Content />
        <Footer />
        <a className="whatsapp_float">
          <BsFillChatRightTextFill
            color="white"
            className="whatsapp-icon"
            onClick={openModal}
          />
        </a>
        {/* <div id="main"></div> */}

        <ContactForm showModal={showModal} setShowModal={setShowModal} />
      </div>
    </StyleRoot>
  );
}

export default App;
